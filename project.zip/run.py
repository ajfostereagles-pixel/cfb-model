"""CLI.

    python run.py backtest --synthetic                 # pipeline self-test
    python run.py backtest --data data/cfb_games.csv   # real backtest (includes the current season so far)
    python run.py predict  --data data/cfb_games.csv --upcoming data/upcoming.csv

If data/team_season.csv exists (made by sportsmodel.fetch_cfbd_extra) the models also use
preseason priors: talent, returning production and last year's SP+.

upcoming.csv columns: game_id, season, week, date (UTC), home_team, away_team,
neutral_site, spread_home, total   (scores not needed; spread negative = home favored)
"""
import argparse
import os

import numpy as np
import pandas as pd
from scipy.stats import norm

from sportsmodel.backtest import (accuracy_report, by_season, evaluate_bets, kelly_sim,
                                  threshold_table, walk_forward)
from sportsmodel.features import build_features, clean_games, load_adv, load_games, load_priors
from sportsmodel.model import MarginModel
from sportsmodel.synthetic import make_synthetic

pd.set_option("display.width", 170)
pd.set_option("display.float_format", lambda v: f"{v:,.3f}")

LABELS = {"blind": "MARKET-BLIND (own signal only)",
          "aware": "MARKET-AWARE (correction on top of the line)",
          "enhanced": "ENHANCED (line + ratings + market-residual form + totals)"}
STRONG, LEAN = 3.0, 2.0   # gap from the line, in points, that earns a "strong" or "lean" pick


def lined_summary(res: pd.DataFrame, mode: str, threshold: float = 2.0) -> dict:
    d = res.dropna(subset=["spread_home", "margin", "pred_margin"])
    edge = d["pred_margin"] + d["spread_home"]
    b = evaluate_bets(d, threshold)
    return {
        "model": mode, "games": len(d),
        "model_mae": np.mean(np.abs(d["margin"] - d["pred_margin"])),
        "market_mae": np.mean(np.abs(d["margin"] - d["mkt_margin"])),
        "avg_gap_pts": np.mean(np.abs(edge)),
        "pct_gap_2plus": np.mean(np.abs(edge) >= 2) * 100,
        "corr_with_line": np.corrcoef(d["pred_margin"], d["mkt_margin"])[0, 1],
        "bets_2pt": b.get("bets", 0), "win_pct": b.get("win_pct", np.nan),
        "roi": b.get("roi", np.nan), "p_value": b.get("p_value_one_sided", np.nan),
    }


def signal_check(res: pd.DataFrame) -> pd.DataFrame:
    """Does the model's disagreement with the line predict anything?
    Group games by how far the model leans home vs the line; a model with real signal
    should see the home side cover more often as the lean gets bigger."""
    d = res.dropna(subset=["spread_home", "margin", "pred_margin"]).copy()
    d["edge"] = d["pred_margin"] + d["spread_home"]
    d["cover"] = d["margin"] + d["spread_home"]
    d = d[d["cover"] != 0]
    bins = [-np.inf, -4, -2, -1, 0, 1, 2, 4, np.inf]
    d["bucket"] = pd.cut(d["edge"], bins)
    g = d.groupby("bucket", observed=True).apply(
        lambda x: pd.Series({"games": len(x), "home_covers_pct": (x["cover"] > 0).mean() * 100}),
        include_groups=False)
    return g


def cmd_backtest(a):
    games = make_synthetic() if a.synthetic else load_games(a.data)
    if a.synthetic:
        print("** SYNTHETIC DATA: this only tests the pipeline, not profitability **\n")
    priors = None if a.synthetic else load_priors(os.path.join(os.path.dirname(a.data), "team_season.csv"))
    adv = None if a.synthetic else load_adv(os.path.join(os.path.dirname(a.data), "adv_games.csv"))
    print("Preseason priors:", "loaded" if priors is not None else "not found (optional)")
    print("Play-by-play stats:", "loaded" if adv is not None else "not found (optional)")
    feat = build_features(games, priors=priors, adv=adv)
    os.makedirs(a.out, exist_ok=True)

    summaries = []
    for mode in ("blind", "aware", "enhanced"):
        print("\n" + "=" * 78 + "\n" + LABELS[mode] + "\n" + "=" * 78)
        res = walk_forward(feat, mode=mode, min_train_seasons=a.min_train)
        print({k: round(v, 3) if isinstance(v, float) else v for k, v in accuracy_report(res).items()})
        print("\nATS by edge threshold (flat 1u @ -110, breakeven 52.38%):")
        print(threshold_table(res).to_string(index=False))
        print(f"\nBy season @ {a.threshold}pt edge:")
        print(by_season(res, a.threshold)[["season", "bets", "win_pct", "roi"]].to_string(index=False))
        print("\nSignal check (does the lean vs the line predict who covers?):")
        print(signal_check(res).to_string())
        print("\nQuarter-Kelly sim:", {k: round(float(v), 2) for k, v in kelly_sim(res, a.threshold).items()})
        res.to_csv(os.path.join(a.out, f"backtest_{mode}.csv"), index=False)
        summaries.append(lined_summary(res, mode, a.threshold))

    print("\n" + "=" * 78 + "\nSIDE BY SIDE (games with a betting line)\n" + "=" * 78)
    s = pd.DataFrame(summaries)
    print(s.to_string(index=False))
    s.to_csv(os.path.join(a.out, "summary.csv"), index=False)


def make_predictions(hist: pd.DataFrame, up: pd.DataFrame, priors=None, adv=None):
    """Train on every finished game, then predict the upcoming ones.

    Returns one row per upcoming game: projected score, win chance, the model's pick against
    the line (if there is a line) and how strong the pick is.
    """
    up = up.copy()
    for c in ("home_points", "away_points"):
        up[c] = np.nan
    up = clean_games(up)
    up = up[~up["game_id"].isin(hist["game_id"])]
    feat = build_features(pd.concat([hist, up], ignore_index=True), priors=priors, adv=adv)
    up_ids = set(up["game_id"])
    train = feat[~feat["game_id"].isin(up_ids) & feat["margin"].notna()]
    todo = feat[feat["game_id"].isin(up_ids)].copy()

    blind = MarginModel(mode="blind").fit(train)
    enh = MarginModel(mode="enhanced").fit(train)
    todo["blind_margin"] = blind.predict_margin(todo)
    has_line = todo["mkt_margin"].notna().values
    todo["enhanced_margin"] = np.nan
    if has_line.any():
        todo.loc[has_line, "enhanced_margin"] = enh.predict_margin(todo[has_line])
    todo["margin_used"] = np.where(has_line, todo["enhanced_margin"], todo["blind_margin"])
    todo["sigma"] = np.where(has_line, enh.sigma, blind.sigma)
    todo["home_win_prob"] = norm.cdf(todo["margin_used"] / todo["sigma"])
    todo["proj_total"] = todo["mkt_total"].fillna(todo["rt_total"])
    todo["gap"] = todo["enhanced_margin"] + todo["spread_home"]          # >0: model likes the home side
    ag = todo["gap"].abs()
    todo["tier"] = np.select([~has_line, ag >= STRONG, ag >= LEAN], ["noline", "strong", "lean"], "pass")
    todo["pick_side"] = np.where(todo["tier"].isin(["strong", "lean"]), np.where(todo["gap"] > 0, "home", "away"), "")
    todo["date"] = pd.to_datetime(todo["date"]).dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    cols = ["game_id", "date", "home_team", "away_team", "neutral_site", "spread_home", "total", "proj_total",
            "blind_margin", "enhanced_margin", "margin_used", "sigma", "home_win_prob", "gap", "tier", "pick_side"]
    return todo[cols].sort_values("date").reset_index(drop=True)


def cmd_predict(a):
    hist = load_games(a.data)
    up = pd.read_csv(a.upcoming)
    priors = load_priors(os.path.join(os.path.dirname(a.data), "team_season.csv"))
    adv = load_adv(os.path.join(os.path.dirname(a.data), "adv_games.csv"))
    out = make_predictions(hist, up, priors, adv)
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    out.to_csv(a.out, index=False)
    show = out.assign(abs_gap=out["gap"].abs()).sort_values("abs_gap", ascending=False, na_position="last")
    print(show.drop(columns=["abs_gap", "game_id"]).to_string(index=False))
    print(f"\nwrote {len(out)} predictions -> {a.out}  "
          f"({(out['tier'] == 'strong').sum()} strong, {(out['tier'] == 'lean').sum()} lean, "
          f"{(out['tier'] == 'pass').sum()} pass, {(out['tier'] == 'noline').sum()} no line)")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("backtest")
    b.add_argument("--data")
    b.add_argument("--synthetic", action="store_true")
    b.add_argument("--min-train", type=int, default=3)
    b.add_argument("--threshold", type=float, default=2.0)
    b.add_argument("--out", default="out")
    p = sub.add_parser("predict")
    p.add_argument("--data", required=True)
    p.add_argument("--upcoming", required=True)
    p.add_argument("--out", default="out/predictions.csv")
    args = ap.parse_args()
    if args.cmd == "backtest":
        if not args.synthetic and not args.data:
            ap.error("give --data or --synthetic")
        cmd_backtest(args)
    else:
        cmd_predict(args)
