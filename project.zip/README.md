# Sports Model (College Football first)

Margin-of-victory Elo + opponent-adjusted offense/defense ratings + market-pricing features -> gradient-boosted
margin models -> win/cover probabilities, validated with a strict walk-forward backtest against betting lines.

## Quick start (no terminal tricks)

1. Paste your CollegeFootballData key into `cfbd_key.txt` (free key: https://collegefootballdata.com/key) and save.
2. Open a terminal in this folder and run:

```
pip install -r requirements.txt
python run_all.py
```

`run_all.py` downloads games and betting lines, tries to download preseason data (optional), runs the backtest,
downloads the coming week's schedule and lines, makes the picks, and builds `dashboard.html`. Double-click `dashboard.html` to open it in your browser.

Other commands:

```bash
python run.py backtest --synthetic                 # pipeline self-test (~15 sec). Expect ~50% ATS.
python run.py backtest --data data/cfb_games.csv   # backtest only
python dashboard/build_dashboard.py                # rebuild dashboard.html from out/*.csv
python run.py predict --data data/cfb_games.csv --upcoming data/upcoming.csv
```

## Three models

- **Market-blind**: never sees the line. Elo, form, opponent-adjusted offense/defense ratings (+ preseason priors if present).
  The honest test of "do I have my own signal?"
- **Market-aware**: starts from the line, learns a correction from Elo and form. Stays very close to the line by construction.
- **Enhanced**: starts from the line and also gets offense/defense ratings, how the market has been pricing each team
  lately, how each team's games run against posted totals, and where the ratings disagree with the line.

## More information is the only lever left (optional downloads)

On 2014-2025 real data, no re-weighting of scores-only features beat the betting line: ridge, boosted trees and blends
all had equal or slightly worse error than the line (the line already contains what scores can say). So the model
can only improve by getting information the line may under-use. `run_all.py` tries to download two optional files:

- `data/team_season.csv` (preseason talent, returning production, last year's SP+), used early in the season.
- `data/adv_games.csv` (play-by-play based success rate and points-added-per-play for every team-game), used as
  rolling team quality that is less noisy than scores.

Both are used automatically when present. Both downloaders were written from the API docs and not yet run against the
live service. Judge any gain by the backtest on seasons the model did not train on (2023-2025), not by one good week.

## What the dashboard shows

Three pages:
- **This week**: the coming games with the model's projected score, win chance and pick (Strong = 3+ points from the
  line, Lean = 2 to 3, otherwise no pick). Each pick shows how that size of pick did in past seasons.
  Without `data/upcoming.csv` it shows a schedule preview with no model picks.
- **Results**: the record, profit, a profit-over-time curve, profit by season/week, and every past pick, per model.
- **Model details**: model vs the line, signal check, results by gap size, season/side/line/time breakdowns, glossary.

## Other sports (NFL, NBA, college basketball, MLB, NHL)

`run_all.py` also downloads these from ESPN's free public feed (no key) and builds `docs/nfl.html`, `nba.html`,
`ncaab.html`, `mlb.html` and `nhl.html`, with a sport switcher at the top of every page.

- The feed has **no past betting lines**, so unlike college football these sports cannot be backtested against the line.
  Each page shows the model's accuracy on past games (scores only), projected scores and win chances.
- NFL, NBA and college basketball are bet on point spreads, so the model moves each line 25% of the way toward its own
  number and marks the biggest gaps as picks. Every pick is saved when first made and graded when the game finishes
  (the **Tracked picks** page). That live record is the test; wait for a few hundred picks before trusting it.
- MLB and NHL are bet on moneylines, so those pages show win chances next to the market's and make no picks.
- The first run reads about five seasons one day at a time and can take 10 to 30 minutes. Later runs only read recent days.
- The downloader was written from the feed's documented shape and not yet run against it: if a sport fails, the others
  still build and the log says which step failed.

## Reading results honestly

- Break-even at -110 is 52.38%. A durable 54% against the spread would be excellent.
- Treat p > 0.05 or fewer than ~1,000 bets as noise. Looking at many breakdowns makes some look good by luck.
- Trust patterns that repeat across seasons. Hold out the latest season and look at it once.
- The best proxy for "money worthy" is closing line value: do your bets beat the final price? Log timestamped picks and prices.
- Not modeled: betting limits, line movement before you bet, injuries, quarterback changes, weather.

## Extending to other sports

The core (Elo, leak-free feature loop, walk-forward, bet evaluation) is sport-agnostic. Per sport, change:

| Sport | Data source | Config changes |
|---|---|---|
| NFL | nflverse / nfl_data_py | K~20, HFA~48, regression ~0.33, add QB-adjustment |
| College basketball | barttorvik / sports-reference | many games: lower K, add tempo + efficiency features |
| NBA | nba_api | rest/back-to-back, travel, injuries matter a lot; lower K |
| MLB | Retrosheet / pybaseball | **starting pitcher is the key feature**; predict run diff, bet moneyline + totals |
| NHL | NHL API / MoneyPuck | low scoring -> model win prob directly (logistic), goalie matters |

Basketball/baseball/hockey need the moneyline or puck/run line in place of a point spread.

Nothing here is financial advice. Only bet what you can afford to lose.

## Put it online and keep it updated (free, GitHub)

1. Create a GitHub account, then a new repository (name it anything) and upload this whole folder to it.
   Do NOT upload `cfbd_key.txt` (the included `.gitignore` already skips it).
2. Repository **Settings > Secrets and variables > Actions > New repository secret**. Name: `CFBD_API_KEY`. Value: your key.
3. **Settings > Pages**: Source = "Deploy from a branch", Branch = `main`, folder = `/docs`. Save.
4. **Actions** tab > "Update dashboard" > **Run workflow**. After a few minutes your page is at
   `https://YOUR-NAME.github.io/REPO-NAME/`. Open it on your phone and add it to your home screen.

It then refreshes itself every morning. Note: Pages on a free account needs a public repository, so the page and
data are public (the key is not, it stays in Secrets).
