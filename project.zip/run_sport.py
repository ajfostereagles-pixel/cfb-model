"""Model, predictions and tracked record for the ESPN sports (NFL, NBA, college basketball, MLB, NHL).

    python run_sport.py nba

Reads  data/<sport>_games.csv and data/<sport>_upcoming.csv (made by sportsmodel.fetch_espn)
Writes out/<sport>_backtest.csv   walk-forward predictions on past games (scores only: no past lines exist in the feed)
       out/<sport>_predictions.csv  projected score, win chance and the model's view against today's line
       data/<sport>_log.csv       every pick the first time it was made, with the line at that moment
       out/<sport>_graded.csv     the logged picks that have finished, with win/loss

Because past betting lines are not available for these sports, the model's edge over the line cannot be
backtested. The picks are tracked live instead and graded as games finish.
"""
import argparse
import os

import numpy as np
import pandas as pd
from scipy.stats import norm

from sportsmodel.backtest import walk_forward, PAYOUT
from sportsmodel.elo import EloConfig
from sportsmodel.features import build_features, clean_games, load_games
from sportsmodel.model import MarginModel
from sportsmodel.sports import SPORTS

SHRINK = 0.25          # how far the model moves the line toward its own number (a cautious guess, not tuned)
LEAN, STRONG = 2.0, 3.0
MAX_PICKS = 10


def feature_kwargs(cfg):
    return dict(elo_cfg=EloConfig(**cfg["elo"]), offdef=cfg["offdef"], pts_per_elo=cfg["pts_per_elo"])


def predict_upcoming(hist, up, cfg):
    up = up.copy()
    for c in ("home_points", "away_points"):
        up[c] = np.nan
    up = clean_games(up)
    up = up[~up["game_id"].isin(hist["game_id"])]
    feat = build_features(pd.concat([hist, up], ignore_index=True), **feature_kwargs(cfg))
    ids = set(up["game_id"])
    train = feat[~feat["game_id"].isin(ids) & feat["margin"].notna()]
    todo = feat[feat["game_id"].isin(ids)].copy()
    m = MarginModel(mode="blind").fit(train)
    todo["blind_margin"] = m.predict_margin(todo)
    line = todo["mkt_margin"]
    has_line = line.notna().values & bool(cfg["spread"])
    todo["margin_used"] = np.where(has_line, line + SHRINK * (todo["blind_margin"] - line), todo["blind_margin"])
    todo["sigma"] = m.sigma
    todo["home_win_prob"] = norm.cdf(todo["margin_used"] / m.sigma)
    todo["proj_total"] = todo["mkt_total"].fillna(todo["rt_total"])
    todo["gap"] = np.where(has_line, todo["margin_used"] + todo["spread_home"], np.nan)
    ag = pd.Series(todo["gap"].values, index=todo.index).abs()
    todo["tier"] = np.select([~has_line, ag >= STRONG, ag >= LEAN], ["info", "strong", "lean"], "pass")
    # only the biggest disagreements become picks
    picks = todo[todo["tier"].isin(["strong", "lean"])].assign(a=ag).sort_values("a", ascending=False)
    demote = picks.index[MAX_PICKS:]
    todo.loc[demote, "tier"] = "pass"
    todo["pick_side"] = np.where(todo["tier"].isin(["strong", "lean"]), np.where(todo["gap"] > 0, "home", "away"), "")
    todo["date"] = pd.to_datetime(todo["date"]).dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    if "home_ml_prob" not in todo.columns:
        todo["home_ml_prob"] = np.nan
    cols = ["game_id", "date", "home_team", "away_team", "neutral_site", "spread_home", "total", "proj_total",
            "blind_margin", "margin_used", "sigma", "home_win_prob", "home_ml_prob", "gap", "tier", "pick_side"]
    return todo[cols].sort_values("date").reset_index(drop=True)


def update_log(pred, hist, logpath):
    cols = ["game_id", "date", "home_team", "away_team", "spread_home", "margin_used", "gap", "tier", "pick_side"]
    log = pd.read_csv(logpath) if os.path.exists(logpath) else pd.DataFrame(columns=cols)
    new = pred[pred["tier"].isin(["strong", "lean"]) & ~pred["game_id"].isin(log["game_id"])][cols]
    if len(new):
        log = pd.concat([log, new], ignore_index=True)
    log.to_csv(logpath, index=False)
    fin = hist.set_index("game_id")
    rows = []
    for r in log.itertuples(index=False):
        if r.game_id not in fin.index:
            continue
        g = fin.loc[r.game_id]
        cover = (g["home_points"] - g["away_points"]) + r.spread_home
        if cover == 0:
            res, units = "push", 0.0
        else:
            win = (cover > 0) == (r.pick_side == "home")
            res, units = ("won", PAYOUT) if win else ("lost", -1.0)
        rows.append(dict(game_id=r.game_id, date=r.date, home_team=r.home_team, away_team=r.away_team,
                         spread_home=r.spread_home, tier=r.tier, pick_side=r.pick_side, gap=r.gap,
                         home_points=g["home_points"], away_points=g["away_points"], result=res, units=units))
    return pd.DataFrame(rows), len(new)


def run(key):
    cfg = SPORTS[key]
    gp = f"data/{key}_games.csv"
    if not os.path.exists(gp):
        raise SystemExit(f"{key}: {gp} not found (run python -m sportsmodel.fetch_espn {key})")
    hist = load_games(gp)
    hist = hist.dropna(subset=["home_points", "away_points"])
    os.makedirs("out", exist_ok=True)
    feat = build_features(hist, **feature_kwargs(cfg))
    bt = walk_forward(feat, "blind", min_train_seasons=2)
    bt[["game_id", "season", "date", "home_team", "away_team", "margin", "pred_margin", "sigma"]].to_csv(
        f"out/{key}_backtest.csv", index=False)
    su = (np.sign(bt["pred_margin"]) == np.sign(bt["margin"]))[bt["margin"] != 0].mean()
    print(f"{key}: backtest {len(bt)} games, picked the winner {su * 100:.1f}% of the time, "
          f"average miss {np.mean(np.abs(bt['margin'] - bt['pred_margin'])):.2f}")
    up_path = f"data/{key}_upcoming.csv"
    up = pd.read_csv(up_path) if os.path.exists(up_path) else pd.DataFrame()
    if len(up):
        pred = predict_upcoming(hist, up, cfg)
    else:
        pred = pd.DataFrame(columns=["game_id", "date", "home_team", "away_team", "neutral_site", "spread_home", "total",
                                     "proj_total", "blind_margin", "margin_used", "sigma", "home_win_prob", "home_ml_prob",
                                     "gap", "tier", "pick_side"])
    pred.to_csv(f"out/{key}_predictions.csv", index=False)
    graded, added = update_log(pred, hist, f"data/{key}_log.csv")
    graded.to_csv(f"out/{key}_graded.csv", index=False)
    print(f"{key}: {len(pred)} predictions, {int(pred['tier'].isin(['strong', 'lean']).sum()) if len(pred) else 0} picks "
          f"({added} newly logged), {len(graded)} graded so far")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("sport", choices=list(SPORTS))
    run(ap.parse_args().sport)
