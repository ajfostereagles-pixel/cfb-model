"""Pull per-game ADVANCED stats (play-by-play based) from the CollegeFootballData API.

    python -m sportsmodel.fetch_cfbd_adv --start 2014 --end 2026

Writes data/adv_games.csv, one row per team per game:
    game_id, season, team, off_ppa, def_ppa, off_sr, def_sr, off_expl, def_expl
PPA is "predicted points added" per play (an EPA-style measure), SR is success rate, expl is
explosiveness. They describe HOW a game was played, not just the score, which is the best
public information that scores alone cannot give. def_* is what the defense ALLOWED.

NOTE: field names follow the CFBD documentation but were not run against the live API when this
was written. Parsing is defensive and the script prints how many rows it parsed per season.
"""
import argparse
import os

import pandas as pd

from .fetch_cfbd import _get, current_season


def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def parse_adv(rows, season):
    out = []
    for r in rows or []:
        gid, team = r.get("gameId", r.get("game_id")), r.get("team")
        off, de = r.get("offense") or {}, r.get("defense") or {}
        if gid is None or not team or not isinstance(off, dict) or not isinstance(de, dict):
            continue
        row = dict(game_id=gid, season=season, team=str(team),
                   off_ppa=_num(off.get("ppa")), def_ppa=_num(de.get("ppa")),
                   off_sr=_num(off.get("successRate")), def_sr=_num(de.get("successRate")),
                   off_expl=_num(off.get("explosiveness")), def_expl=_num(de.get("explosiveness")))
        if row["off_ppa"] is not None and row["def_ppa"] is not None:
            out.append(row)
    return out


def fetch(start, end, key):
    rows = []
    for year in range(start, end + 1):
        got = parse_adv(_get("/stats/game/advanced", {"year": year}, key), year)
        print(f"{year}: {len(got)} team-games")
        rows += got
    return pd.DataFrame(rows)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", type=int, default=2014)
    ap.add_argument("--end", type=int, default=current_season())
    ap.add_argument("--out", default="data/adv_games.csv")
    a = ap.parse_args()
    key = os.environ.get("CFBD_API_KEY")
    if not key:
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        kp = os.path.join(here, "cfbd_key.txt")
        if os.path.exists(kp):
            key = open(kp).read().strip()
    if not key or key == "PASTE_YOUR_KEY_HERE":
        raise SystemExit("No API key found. Open cfbd_key.txt, paste your key, save, and run again.")
    df = fetch(a.start, a.end, key)
    if df.empty:
        raise SystemExit("Parsed no advanced stats; the API field names may have changed. "
                         "The backtest still works without this file.")
    df.to_csv(a.out, index=False)
    print(f"wrote {len(df)} team-games -> {a.out}")
