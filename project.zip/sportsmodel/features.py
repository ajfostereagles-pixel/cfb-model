"""Leak-free feature builder.

Every feature for a game is computed from information available BEFORE kickoff.
Games are processed in chronological order; state is updated only after the
features for that game have been recorded. Games with no final score (upcoming
games) get features but do not update any state.

Feature families
  * Elo + recent form                      (team strength from results)
  * Offense / defense ratings              (opponent-adjusted points scored and allowed)
  * Market-residual form                   (has the market been under- or over-rating this team lately?)
  * Totals form                            (do this team's games go over or under the posted total?)
  * Preseason priors (optional file)       (talent, returning production, last year's SP+)
"""
import os
from collections import defaultdict, deque

import numpy as np
import pandas as pd

from .elo import EloConfig, EloState

REQUIRED = ["game_id", "season", "week", "date", "home_team", "away_team",
            "home_points", "away_points", "neutral_site"]
PRIOR_NAMES = ["talent", "ret_ppa", "prev_sp", "prev_sp_off", "prev_sp_def"]


def load_games(path: str) -> pd.DataFrame:
    return clean_games(pd.read_csv(path))


def load_priors(path: str):
    """Optional preseason table: season, team, talent, ret_ppa, prev_sp, prev_sp_off, prev_sp_def."""
    if not os.path.exists(path):
        return None
    pri = pd.read_csv(path)
    keep = ["season", "team"] + [c for c in PRIOR_NAMES if c in pri.columns]
    return pri[keep] if len(keep) > 2 else None


def clean_games(df: pd.DataFrame) -> pd.DataFrame:
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError(f"games data is missing columns: {missing}")
    df = df.copy()
    d = pd.to_datetime(df["date"])
    if d.dt.tz is not None:
        d = d.dt.tz_localize(None)
    df["date"] = d
    df["neutral_site"] = df["neutral_site"].fillna(False).astype(bool)
    for c in ("spread_home", "total"):
        if c not in df.columns:
            df[c] = np.nan
    return df.sort_values(["date", "game_id"]).reset_index(drop=True)


class OffDef:
    """Online opponent-adjusted offense/defense ratings, in points.

    expected home points = league mean + home offense + away defense leakiness + home edge
    Each game nudges the four ratings involved by a fraction of the surprise.
    Defense rating is points ALLOWED relative to average, so higher means a worse defense.
    """

    def __init__(self, lr=0.07, regress=0.35, hfa=1.25):
        self.o, self.d = {}, {}
        self.lr, self.regress, self.hfa = lr, regress, hfa
        self.season, self.tot, self.n = None, 0.0, 0

    @property
    def mu(self):
        return self.tot / self.n if self.n >= 100 else 28.0

    def new_season(self, season):
        if self.season is not None and season != self.season:
            for t in self.o:
                self.o[t] *= 1 - self.regress
            for t in self.d:
                self.d[t] *= 1 - self.regress
        self.season = season

    def expect(self, home, away, neutral):
        h = 0.0 if neutral else self.hfa
        eh = self.mu + self.o.get(home, 0.0) + self.d.get(away, 0.0) + h
        ea = self.mu + self.o.get(away, 0.0) + self.d.get(home, 0.0) - h
        return eh, ea

    def update(self, home, away, hp, ap, neutral):
        eh, ea = self.expect(home, away, neutral)
        errh, erra = hp - eh, ap - ea
        self.o[home] = self.o.get(home, 0.0) + self.lr * errh
        self.d[away] = self.d.get(away, 0.0) + self.lr * errh
        self.o[away] = self.o.get(away, 0.0) + self.lr * erra
        self.d[home] = self.d.get(home, 0.0) + self.lr * erra
        self.tot += hp + ap
        self.n += 2


ADV_COLS = ["off_ppa", "def_ppa", "off_sr", "def_sr"]


def load_adv(path: str):
    """Optional per-game advanced stats from fetch_cfbd_adv (game_id, team, off_ppa, def_ppa, off_sr, def_sr)."""
    if not os.path.exists(path):
        return None
    a = pd.read_csv(path)
    return a if {"game_id", "team"} | set(ADV_COLS) <= set(a.columns) else None


def build_features(games: pd.DataFrame, elo_cfg: EloConfig | None = None,
                   form_window: int = 5, priors: pd.DataFrame | None = None,
                   adv: pd.DataFrame | None = None, adv_window: int = 8) -> pd.DataFrame:
    g = clean_games(games)
    state = EloState(elo_cfg or EloConfig())
    rat = OffDef()
    form = defaultdict(lambda: deque(maxlen=form_window))   # team -> (pf, pa)
    mres = defaultdict(lambda: deque(maxlen=form_window))   # team -> margin minus market margin
    tres = defaultdict(lambda: deque(maxlen=form_window))   # team -> total points minus posted total
    last_date: dict[str, pd.Timestamp] = {}
    gp = defaultdict(int)  # (team, season) -> games played
    advd = defaultdict(lambda: deque(maxlen=adv_window))  # team -> (off_ppa, def_ppa, off_sr, def_sr)
    adv_map = {}
    if adv is not None:
        for a in adv.dropna(subset=ADV_COLS).itertuples(index=False):
            adv_map[(a.game_id, a.team)] = (a.off_ppa, a.def_ppa, a.off_sr, a.def_sr)

    rows = []
    for r in g.itertuples(index=False):
        state.new_season(r.season)
        rat.new_season(r.season)
        eh, ea = state.get(r.home_team), state.get(r.away_team)
        hfa = 0.0 if r.neutral_site else state.cfg.hfa
        eph, epa = rat.expect(r.home_team, r.away_team, r.neutral_site)
        mm = -r.spread_home if pd.notna(r.spread_home) else np.nan
        rec = {
            "elo_h": eh, "elo_a": ea, "elo_diff": eh + hfa - ea,
            "neutral": int(r.neutral_site),
            "h_off": rat.o.get(r.home_team, 0.0), "h_def": rat.d.get(r.home_team, 0.0),
            "a_off": rat.o.get(r.away_team, 0.0), "a_def": rat.d.get(r.away_team, 0.0),
            "rt_margin": eph - epa, "rt_total": eph + epa,
            "gap_rt": (eph - epa) - mm, "gap_elo": (eh + hfa - ea) / 25.0 - mm,
        }
        for side, team in (("h", r.home_team), ("a", r.away_team)):
            d = form[team]
            if d:
                arr = np.asarray(d, dtype=float)
                rec[f"{side}_pf5"] = arr[:, 0].mean()
                rec[f"{side}_pa5"] = arr[:, 1].mean()
                rec[f"{side}_mar5"] = (arr[:, 0] - arr[:, 1]).mean()
            else:
                rec[f"{side}_pf5"] = rec[f"{side}_pa5"] = rec[f"{side}_mar5"] = np.nan
            rec[f"{side}_mres5"] = float(np.mean(mres[team])) if mres[team] else np.nan
            rec[f"{side}_tres5"] = float(np.mean(tres[team])) if tres[team] else np.nan
            if adv is not None:
                arr = np.asarray(advd[team], dtype=float) if advd[team] else None
                for j, nm in enumerate(("oppa", "dppa", "osr", "dsr")):
                    rec[f"{side}_{nm}"] = arr[:, j].mean() if arr is not None else np.nan
            rec[f"{side}_rest"] = min((r.date - last_date[team]).days, 21) if team in last_date else np.nan
            rec[f"{side}_gp"] = gp[(team, r.season)]
        if adv is not None:
            rec["ppa_edge"] = (rec["h_oppa"] - rec["h_dppa"]) - (rec["a_oppa"] - rec["a_dppa"])
            rec["sr_edge"] = (rec["h_osr"] - rec["h_dsr"]) - (rec["a_osr"] - rec["a_dsr"])
        rows.append(rec)

        # ---- update state only after features are recorded ----
        if pd.notna(r.home_points) and pd.notna(r.away_points):
            hp, ap = r.home_points, r.away_points
            state.update(r.home_team, r.away_team, hp, ap, r.neutral_site)
            rat.update(r.home_team, r.away_team, hp, ap, r.neutral_site)
            form[r.home_team].append((hp, ap))
            form[r.away_team].append((ap, hp))
            if pd.notna(mm):
                res = (hp - ap) - mm
                mres[r.home_team].append(res)
                mres[r.away_team].append(-res)
            if pd.notna(r.total):
                tr = hp + ap - r.total
                tres[r.home_team].append(tr)
                tres[r.away_team].append(tr)
            for team in (r.home_team, r.away_team):
                v = adv_map.get((r.game_id, team))
                if v is not None:
                    advd[team].append(v)
            last_date[r.home_team] = r.date
            last_date[r.away_team] = r.date
            gp[(r.home_team, r.season)] += 1
            gp[(r.away_team, r.season)] += 1

    feat = pd.concat([g, pd.DataFrame(rows)], axis=1)
    feat["margin"] = feat["home_points"] - feat["away_points"]
    feat["mkt_margin"] = -feat["spread_home"]  # expected home margin implied by the market
    feat["mkt_total"] = feat["total"]
    if priors is not None:
        feat = add_priors(feat, priors)
    return feat


def add_priors(feat: pd.DataFrame, pri: pd.DataFrame) -> pd.DataFrame:
    cols = [c for c in pri.columns if c not in ("season", "team")]
    h = pri.rename(columns={"team": "home_team", **{c: f"h_{c}" for c in cols}})
    a = pri.rename(columns={"team": "away_team", **{c: f"a_{c}" for c in cols}})
    feat = feat.merge(h, on=["season", "home_team"], how="left").merge(a, on=["season", "away_team"], how="left")
    for c in cols:
        feat[f"{c}_diff"] = feat[f"h_{c}"] - feat[f"a_{c}"]
    return feat
