"""Per-sport settings for the ESPN-based sports (college football has its own CFBD pipeline).

pts_per_elo : how many Elo points equal one point (or run/goal) of margin
spread      : True when the sport is bet against a point spread (picks are possible)
edge        : gap in points between the model and the line before a game is logged as a pick
"""
SPORTS = {
    "nfl": dict(name="NFL", path="football/nfl", start=2020, months=(9, 10, 11, 12, 1, 2), groups=None, spread=True, edge=3.0, label="points",
                elo=dict(k=20.0, hfa=48.0, regress=0.33, new_team=1450.0), pts_per_elo=25.0,
                offdef=dict(lr=0.07, regress=0.35, hfa=1.6, mu_default=22.5)),
    "nba": dict(name="NBA", path="basketball/nba", start=2020, months=(10, 11, 12, 1, 2, 3, 4, 5, 6), groups=None, spread=True, edge=4.0, label="points",
                elo=dict(k=18.0, hfa=90.0, regress=0.25, new_team=1450.0), pts_per_elo=28.0,
                offdef=dict(lr=0.03, regress=0.30, hfa=2.4, mu_default=112.0)),
    "ncaab": dict(name="College basketball", path="basketball/mens-college-basketball", start=2020, months=(11, 12, 1, 2, 3, 4), groups=50, spread=True,
                  edge=4.0, label="points", college=True,
                  elo=dict(k=26.0, hfa=85.0, regress=0.35, new_team=1350.0), pts_per_elo=25.0,
                  offdef=dict(lr=0.04, regress=0.40, hfa=3.0, mu_default=72.0)),
    "mlb": dict(name="MLB", path="baseball/mlb", start=2020, months=(3, 4, 5, 6, 7, 8, 9, 10, 11), groups=None, spread=False, edge=None, label="runs",
                elo=dict(k=4.0, hfa=24.0, regress=0.30, new_team=1500.0), pts_per_elo=70.0,
                offdef=dict(lr=0.02, regress=0.30, hfa=0.25, mu_default=4.5)),
    "nhl": dict(name="NHL", path="hockey/nhl", start=2020, months=(10, 11, 12, 1, 2, 3, 4, 5, 6), groups=None, spread=False, edge=None, label="goals",
                elo=dict(k=6.0, hfa=33.0, regress=0.30, new_team=1500.0), pts_per_elo=80.0,
                offdef=dict(lr=0.02, regress=0.30, hfa=0.2, mu_default=3.0)),
}
ORDER = ["nfl", "nba", "ncaab", "mlb", "nhl"]
