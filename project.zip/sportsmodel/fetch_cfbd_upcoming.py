"""Pull the coming week's college football schedule and betting lines.

    python -m sportsmodel.fetch_cfbd_upcoming

Writes data/upcoming.csv: game_id, season, week, date (UTC), home_team, away_team,
neutral_site, spread_home (negative = home favored), total.

Only games that have not finished and start within the next 10 days are kept (games that
kicked off in the last 6 hours are kept too, so a same-day slate stays complete). Games
between two lower-division teams with no betting line are dropped.

NOTE: field names follow the CFBD documentation but were not run against the live API when
this was written. The script prints what it found so a mismatch is obvious.
"""
import argparse
import os

import numpy as np
import pandas as pd

from .fetch_cfbd import _get, _pick_line, current_season


def fetch_upcoming(key, days=10, sign=1.0):
    now = pd.Timestamp.now(tz="UTC")
    year = current_season()
    rows = []
    for st in ("regular", "postseason"):
        games = _get("/games", {"year": year, "seasonType": st}, key)
        lines = _get("/lines", {"year": year, "seasonType": st}, key)
        line_map = {l["id"]: _pick_line(l.get("lines", [])) for l in lines}
        for g in games:
            if g.get("completed"):
                continue
            start = pd.to_datetime(g.get("startDate"), utc=True, errors="coerce")
            if pd.isna(start) or start < now - pd.Timedelta(hours=6) or start > now + pd.Timedelta(days=days):
                continue
            spread, total = line_map.get(g["id"], (np.nan, np.nan))
            hc, ac = str(g.get("homeClassification", "")).lower(), str(g.get("awayClassification", "")).lower()
            both_fbs = hc == "fbs" and ac == "fbs"
            if (hc or ac) and not (both_fbs or pd.notna(spread)):
                continue
            rows.append(dict(game_id=g["id"], season=g["season"], week=g["week"],
                             date=start.tz_convert("UTC").tz_localize(None).strftime("%Y-%m-%d %H:%M:%S"),
                             home_team=g["homeTeam"], away_team=g["awayTeam"],
                             neutral_site=bool(g.get("neutralSite")),
                             spread_home=sign * spread if pd.notna(spread) else np.nan, total=total))
    df = pd.DataFrame(rows)
    print(f"{len(df)} upcoming games in the next {days} days, {df['spread_home'].notna().sum() if len(df) else 0} with a line")
    return df


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=10)
    ap.add_argument("--out", default="data/upcoming.csv")
    a = ap.parse_args()
    key = os.environ.get("CFBD_API_KEY")
    if not key:
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        kp = os.path.join(here, "cfbd_key.txt")
        if os.path.exists(kp):
            key = open(kp).read().strip()
    if not key or key == "PASTE_YOUR_KEY_HERE":
        raise SystemExit("No API key found. Open cfbd_key.txt, paste your key, save, and run again.")
    sp = os.path.join(os.path.dirname(a.out) or ".", "spread_sign.txt")
    sign = float(open(sp).read().strip()) if os.path.exists(sp) else 1.0
    df = fetch_upcoming(key, a.days, sign)
    if df.empty:
        raise SystemExit("No upcoming games found. That is normal in the offseason or between weeks.")
    df.to_csv(a.out, index=False)
    print(f"wrote {len(df)} games -> {a.out}")
