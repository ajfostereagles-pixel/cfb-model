"""Synthetic league generator, used ONLY to test that the pipeline works.

Results on synthetic data say nothing about real-world profitability. The point is
to check for leakage and bugs: with an efficient market the model should land near
50% ATS; with a market that lags true strength it should find a modest edge.
"""
import numpy as np
import pandas as pd


def make_synthetic(n_teams=130, seasons=range(2014, 2026), weeks=12, seed=7,
                   market_lag=2, market_noise=1.5) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    teams = [f"Team{i:03d}" for i in range(n_teams)]
    strength = rng.normal(0, 10, n_teams)
    rows, gid = [], 0
    for season in seasons:
        strength = 0.8 * strength + rng.normal(0, 6, n_teams)  # offseason churn
        hist = [strength.copy()]
        for week in range(1, weeks + 1):
            strength = strength + rng.normal(0, 0.8, n_teams)   # in-season drift
            hist.append(strength.copy())
            seen = hist[max(0, len(hist) - 1 - market_lag)]     # market sees stale strength
            perm = rng.permutation(n_teams)
            date = pd.Timestamp(f"{season}-09-01") + pd.Timedelta(days=7 * (week - 1))
            for i in range(0, n_teams - 1, 2):
                h, a = perm[i], perm[i + 1]
                neutral = rng.random() < 0.05
                hfa = 0.0 if neutral else 2.8
                exp = strength[h] - strength[a] + hfa
                margin = int(round(exp + rng.normal(0, 13))) or 1
                total = float(np.clip(55 + rng.normal(0, 10), 25, 95))
                hp = max(0, int(round(total / 2 + margin / 2)))
                ap = max(0, hp - margin)
                hp = ap + margin
                mkt = seen[h] - seen[a] + hfa + rng.normal(0, market_noise)
                rows.append(dict(game_id=gid, season=season, week=week, date=date,
                                 home_team=teams[h], away_team=teams[a],
                                 home_points=hp, away_points=ap, neutral_site=neutral,
                                 spread_home=-round(mkt * 2) / 2))
                gid += 1
    return pd.DataFrame(rows)
