"""Walk-forward backtest and betting evaluation.

Each test season is predicted by a model trained ONLY on earlier seasons.
"""
import numpy as np
import pandas as pd
from scipy.stats import norm

from .model import MarginModel

BREAKEVEN = 110 / 210  # 52.38% needed at -110 odds
PAYOUT = 100 / 110


def walk_forward(feat: pd.DataFrame, mode: str, min_train_seasons: int = 3, **model_kw) -> pd.DataFrame:
    seasons = sorted(feat["season"].unique())
    out = []
    for s in seasons[min_train_seasons:]:
        train = feat[(feat["season"] < s) & feat["margin"].notna()]
        test = feat[(feat["season"] == s) & feat["margin"].notna()].copy()
        if mode in ("aware", "enhanced"):
            test = test.dropna(subset=["mkt_margin"])
        m = MarginModel(mode=mode, **model_kw).fit(train)
        test["pred_margin"] = m.predict_margin(test)
        test["sigma"] = m.sigma
        out.append(test)
    return pd.concat(out, ignore_index=True)


def accuracy_report(df: pd.DataFrame) -> dict:
    d = df.dropna(subset=["spread_home", "margin"])
    res = {
        "n_games": len(df),
        "model_mae": float(np.mean(np.abs(df["margin"] - df["pred_margin"]))),
        "straight_up_acc": float(np.mean(np.sign(df["pred_margin"]) == np.sign(df["margin"]))),
    }
    if len(d):
        res["market_mae"] = float(np.mean(np.abs(d["margin"] - d["mkt_margin"])))
        res["model_mae_on_lined_games"] = float(np.mean(np.abs(d["margin"] - d["pred_margin"])))
    return res


def evaluate_bets(df: pd.DataFrame, threshold: float = 2.0) -> dict:
    """Flat 1-unit bets at -110 on the side where model and market disagree by >= threshold points."""
    d = df.dropna(subset=["spread_home", "margin"]).copy()
    d["edge"] = d["pred_margin"] + d["spread_home"]  # >0 -> model likes home against the number
    d["cover"] = d["margin"] + d["spread_home"]
    d = d[(d["edge"].abs() >= threshold) & (d["cover"] != 0)]
    if d.empty:
        return {"threshold": threshold, "bets": 0}
    bet_home = d["edge"] > 0
    win = np.where(bet_home, d["cover"] > 0, d["cover"] < 0)
    n, w = len(d), int(win.sum())
    profit = w * PAYOUT - (n - w)
    z = (w - n * BREAKEVEN) / np.sqrt(n * BREAKEVEN * (1 - BREAKEVEN))
    return {"threshold": threshold, "bets": n, "wins": w, "win_pct": w / n,
            "roi": profit / n, "units": profit, "z_vs_breakeven": float(z),
            "p_value_one_sided": float(1 - norm.cdf(z))}


def threshold_table(df: pd.DataFrame, thresholds=(0, 1, 2, 3, 4, 5)) -> pd.DataFrame:
    return pd.DataFrame([evaluate_bets(df, t) for t in thresholds])


def by_season(df: pd.DataFrame, threshold: float = 2.0) -> pd.DataFrame:
    rows = []
    for s, g in df.groupby("season"):
        r = evaluate_bets(g, threshold)
        r["season"] = s
        rows.append(r)
    return pd.DataFrame(rows)


def kelly_sim(df: pd.DataFrame, threshold: float = 2.0, kelly_frac: float = 0.25,
              max_bet: float = 0.03, shrink: float = 0.5, bankroll0: float = 100.0) -> dict:
    """Fractional-Kelly bankroll simulation.

    The raw model cover probability is shrunk toward 50% (shrink=0.5 keeps half the
    edge) because model probabilities are almost always overconfident.
    """
    d = df.dropna(subset=["spread_home", "margin"]).copy()
    d["edge"] = d["pred_margin"] + d["spread_home"]
    d["cover"] = d["margin"] + d["spread_home"]
    d = d[(d["edge"].abs() >= threshold) & (d["cover"] != 0)].sort_values("date")
    br, peak, max_dd = bankroll0, bankroll0, 0.0
    for r in d.itertuples():
        p_home = norm.cdf(r.edge / r.sigma)
        p = 0.5 + shrink * (max(p_home, 1 - p_home) - 0.5)
        f = max(0.0, (p * PAYOUT - (1 - p)) / PAYOUT) * kelly_frac
        stake = br * min(f, max_bet)
        won = (r.cover > 0) if r.edge > 0 else (r.cover < 0)
        br += stake * PAYOUT if won else -stake
        peak = max(peak, br)
        max_dd = max(max_dd, (peak - br) / peak)
    return {"bets": len(d), "final_bankroll": br, "return_pct": (br / bankroll0 - 1) * 100,
            "max_drawdown_pct": max_dd * 100}
