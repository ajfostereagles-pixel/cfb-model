"""Pull PRESEASON information from the CollegeFootballData API.

The betting market leans hard on this early in the season, before results exist, so
it is where a model most needs something the scores alone cannot provide.

    python -m sportsmodel.fetch_cfbd_extra --start 2014 --end 2025

Writes data/team_season.csv with one row per team per season:
    season, team,
    talent        recruiting talent composite for that season's roster
    ret_ppa       share of last year's production that returns (0 to 1)
    prev_sp       last season's FINAL SP+ rating (never the current season's: that would leak)
    prev_sp_off   last season's SP+ offense rating
    prev_sp_def   last season's SP+ defense rating

NOTE: response field names below follow the CFBD documentation but were not run against the
live API when this was written. Parsing is defensive (several field names tried, bad rows
skipped) and the script prints how many rows it parsed per source, so a mismatch is obvious.
"""
import argparse
import os

import pandas as pd

from .fetch_cfbd import _get, current_season


def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _team(row):
    t = row.get("team") or row.get("school")
    if not t or str(t).lower() in ("nationalaverages", "national averages"):
        return None
    return str(t)


def parse_talent(rows):
    out = {}
    for r in rows or []:
        t, v = _team(r), _num(r.get("talent"))
        if t and v is not None:
            out[t] = v
    return out


def parse_returning(rows):
    out = {}
    for r in rows or []:
        t = _team(r)
        v = _num(r.get("percentPPA"))
        if v is None:
            v = _num(r.get("percentPpa"))
        if t and v is not None:
            out[t] = v
    return out


def parse_sp(rows):
    out = {}
    for r in rows or []:
        t = _team(r)
        if not t:
            continue
        off, de = r.get("offense") or {}, r.get("defense") or {}
        out[t] = {"prev_sp": _num(r.get("rating")),
                  "prev_sp_off": _num(off.get("rating")) if isinstance(off, dict) else None,
                  "prev_sp_def": _num(de.get("rating")) if isinstance(de, dict) else None}
    return out


def build_table(season, talent, returning, sp_prev):
    teams = set(talent) | set(returning) | set(sp_prev)
    rows = []
    for t in sorted(teams):
        sp = sp_prev.get(t, {})
        rows.append({"season": season, "team": t, "talent": talent.get(t), "ret_ppa": returning.get(t),
                     "prev_sp": sp.get("prev_sp"), "prev_sp_off": sp.get("prev_sp_off"),
                     "prev_sp_def": sp.get("prev_sp_def")})
    return rows


def fetch(start, end, key):
    rows = []
    for year in range(start, end + 1):
        tal = parse_talent(_get("/talent", {"year": year}, key))
        ret = parse_returning(_get("/player/returning", {"year": year}, key))
        sp = parse_sp(_get("/ratings/sp", {"year": year - 1}, key))
        print(f"{year}: talent {len(tal)} teams, returning {len(ret)}, last year's SP+ {len(sp)}")
        rows += build_table(year, tal, ret, sp)
    return pd.DataFrame(rows)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", type=int, default=2014)
    ap.add_argument("--end", type=int, default=current_season())
    ap.add_argument("--out", default="data/team_season.csv")
    a = ap.parse_args()
    key = os.environ.get("CFBD_API_KEY")
    if not key:
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        kp = os.path.join(here, "cfbd_key.txt")
        if os.path.exists(kp):
            key = open(kp).read().strip()
    if not key or key == "PASTE_YOUR_KEY_HERE":
        raise SystemExit("No API key found. Open cfbd_key.txt, paste your key, save, and run again.")
    df = fetch(a.start, a.end, key)
    if df.empty or df[["talent", "ret_ppa", "prev_sp"]].notna().sum().max() == 0:
        raise SystemExit("Parsed no usable preseason data; the API field names may have changed. "
                         "The backtest still works without this file.")
    df.to_csv(a.out, index=False)
    print(f"wrote {len(df)} team-seasons -> {a.out}")
