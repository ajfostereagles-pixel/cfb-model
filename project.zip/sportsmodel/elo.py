"""Margin-of-victory Elo with home-field advantage and offseason regression.

Sport-specific knobs live in EloConfig, so the same engine can be reused for
the NFL, NBA, MLB, etc. by swapping the config (K, HFA, regression).
"""
from dataclasses import dataclass
import numpy as np


@dataclass
class EloConfig:
    k: float = 22.0          # update speed
    hfa: float = 55.0        # home-field advantage in Elo points
    base: float = 1500.0     # league-average rating
    new_team: float = 1350.0  # rating for a team seen for the first time
    regress: float = 0.30    # fraction regressed to base each new season
    scale: float = 400.0     # logistic scale


class EloState:
    def __init__(self, cfg: EloConfig):
        self.cfg = cfg
        self.r: dict[str, float] = {}
        self.season = None

    def get(self, team: str) -> float:
        return self.r.get(team, self.cfg.new_team)

    def new_season(self, season) -> None:
        """Regress every rating toward the mean when a new season begins."""
        if self.season is not None and season != self.season:
            c = self.cfg
            for t in self.r:
                self.r[t] = self.r[t] * (1 - c.regress) + c.base * c.regress
        self.season = season

    def update(self, home: str, away: str, hp: float, ap: float, neutral: bool) -> None:
        c = self.cfg
        eh, ea = self.get(home), self.get(away)
        dr = eh + (0.0 if neutral else c.hfa) - ea
        exp_h = 1.0 / (1.0 + 10 ** (-dr / c.scale))
        margin = hp - ap
        if margin == 0:
            return
        act = 1.0 if margin > 0 else 0.0
        winner_dr = dr if margin > 0 else -dr
        # 538-style multiplier: dampens blowouts and favorite-padding
        mult = np.log(abs(margin) + 1.0) * 2.2 / (winner_dr * 0.001 + 2.2)
        delta = c.k * mult * (act - exp_h)
        self.r[home] = eh + delta
        self.r[away] = ea - delta
