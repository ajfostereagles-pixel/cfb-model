"""Pull college football games + betting lines from the CollegeFootballData API.

Run this on YOUR machine (free API key: https://collegefootballdata.com/key).

    export CFBD_API_KEY=your_key
    python -m sportsmodel.fetch_cfbd --start 2014 --end 2025 --out data/cfb_games.csv

Output columns match what the model expects:
    game_id, season, week, date, home_team, away_team, home_points, away_points,
    neutral_site, spread_home (negative = home favored), total
"""
import argparse
import datetime
import os
import time

import numpy as np
import pandas as pd
import requests

BASE = "https://api.collegefootballdata.com"
PROVIDER_PREF = ["DraftKings", "Bovada", "ESPN Bet", "consensus"]


def current_season():
    """The CFBD season year: a season that starts in the fall keeps that year until the next July."""
    t = datetime.date.today()
    return t.year if t.month >= 7 else t.year - 1


def _get(path, params, key):
    for attempt in range(3):
        r = requests.get(BASE + path, params=params,
                         headers={"Authorization": f"Bearer {key}"}, timeout=60)
        if r.status_code == 429:
            time.sleep(5 * (attempt + 1))
            continue
        r.raise_for_status()
        return r.json()
    raise RuntimeError(f"rate limited on {path}")


def _pick_line(lines):
    """Prefer a named sportsbook; otherwise average whatever providers exist."""
    usable = [l for l in lines if l.get("spread") is not None]
    if not usable:
        return np.nan, np.nan
    for p in PROVIDER_PREF:
        for l in usable:
            if l.get("provider") == p:
                return float(l["spread"]), l.get("overUnder")
    return float(np.mean([l["spread"] for l in usable])), usable[0].get("overUnder")


def fetch(start, end, key):
    rows = []
    for year in range(start, end + 1):
        for st in ("regular", "postseason"):
            games = _get("/games", {"year": year, "seasonType": st}, key)
            lines = _get("/lines", {"year": year, "seasonType": st}, key)
            line_map = {l["id"]: _pick_line(l.get("lines", [])) for l in lines}
            for g in games:
                if g.get("homePoints") is None or g.get("awayPoints") is None or g.get("completed") is False:
                    continue  # unplayed or still in progress
                spread, total = line_map.get(g["id"], (np.nan, np.nan))
                rows.append(dict(
                    game_id=g["id"], season=g["season"], week=g["week"],
                    date=g["startDate"], home_team=g["homeTeam"], away_team=g["awayTeam"],
                    home_points=g["homePoints"], away_points=g["awayPoints"],
                    neutral_site=bool(g.get("neutralSite")), spread_home=spread, total=total))
            print(f"{year} {st}: {len(games)} games")
    df = pd.DataFrame(rows)
    df["date"] = pd.to_datetime(df["date"], utc=True).dt.tz_localize(None)

    # Sanity-check the sign convention: a home favorite has a NEGATIVE spread, so
    # spread_home should correlate NEGATIVELY with the home margin. Flip if not.
    d = df.dropna(subset=["spread_home"])
    corr = np.corrcoef(d["spread_home"], d["home_points"] - d["away_points"])[0, 1]
    print(f"corr(spread_home, margin) = {corr:.3f}")
    flipped = bool(corr > 0)
    if flipped:
        print("Sign convention looks flipped; negating spread_home.")
        df["spread_home"] = -df["spread_home"]
    df.attrs["flipped"] = flipped
    return df


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", type=int, default=2014)
    ap.add_argument("--end", type=int, default=current_season())
    ap.add_argument("--out", default="data/cfb_games.csv")
    a = ap.parse_args()
    key = os.environ.get("CFBD_API_KEY")
    if not key:
        # Easiest option: paste the key into cfbd_key.txt in the project folder
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        kp = os.path.join(here, "cfbd_key.txt")
        if os.path.exists(kp):
            key = open(kp).read().strip()
    if not key or key == "PASTE_YOUR_KEY_HERE":
        raise SystemExit("No API key found. Open cfbd_key.txt, replace PASTE_YOUR_KEY_HERE "
                         "with your key, save the file, and run again.")
    out = fetch(a.start, a.end, key)
    out.to_csv(a.out, index=False)
    # remember the spread sign convention so upcoming-game lines are treated the same way
    with open(os.path.join(os.path.dirname(a.out) or ".", "spread_sign.txt"), "w") as f:
        f.write("-1" if out.attrs.get("flipped") else "1")
    print(f"wrote {len(out)} games -> {a.out}  (with lines: {out['spread_home'].notna().sum()})")
