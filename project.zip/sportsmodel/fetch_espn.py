"""Download games and betting lines for the other sports from ESPN's public scoreboard feed (no key needed).

    python -m sportsmodel.fetch_espn nba            # one sport
    python -m sportsmodel.fetch_espn all

Reads one day per request (the feed ignores date ranges), in parallel. Writes, per sport:
    data/<sport>_games.csv     finished games since 2018 (scores). Past betting lines are NOT available from this feed.
    data/<sport>_upcoming.csv  games in the next few days with the current line when one is posted

The first run downloads everything; later runs only re-read the last couple of weeks.
NOTE: written from the feed's documented shape and not run against it here, so the script prints counts
for every step to make a mismatch obvious.
"""
import argparse
import datetime as dt
import os
import re
import time

import numpy as np
import pandas as pd
import requests

from .sports import ORDER, SPORTS

BASE = "https://site.api.espn.com/apis/site/v2/sports/{path}/scoreboard"
UA = {"User-Agent": "Mozilla/5.0 (compatible; sports-model)"}


def _get(path, params, tries=4):
    url = BASE.format(path=path)
    for i in range(tries):
        try:
            r = requests.get(url, params=params, headers=UA, timeout=40)
            if r.status_code == 200:
                return r.json()
            if r.status_code in (429, 500, 502, 503):
                time.sleep(2 * (i + 1))
                continue
            return {}
        except requests.RequestException:
            time.sleep(2 * (i + 1))
    return {}


def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _ml_to_prob(s):
    """American moneyline text like '-470' or '+360' to implied probability (not vig-free)."""
    v = _num(str(s).replace("+", "")) if s is not None else None
    if v is None or v == 0:
        return None
    return 100 / (v + 100) if v > 0 else -v / (-v + 100)


def parse_odds(comp, home_is_favorite_hint=None):
    """Return spread_home (negative = home favored), total, home/away implied win probability."""
    odds = comp.get("odds") or []
    if not odds:
        return np.nan, np.nan, np.nan, np.nan
    o = odds[0]
    spread, total = _num(o.get("spread")), _num(o.get("overUnder"))
    h, a = o.get("homeTeamOdds") or {}, o.get("awayTeamOdds") or {}
    if spread is not None:
        if h.get("favorite") is True:
            spread = -abs(spread)
        elif a.get("favorite") is True:
            spread = abs(spread)
    ml = o.get("moneyline") or {}
    hml = ((ml.get("home") or {}).get("close") or {}).get("odds") or h.get("moneyLine")
    aml = ((ml.get("away") or {}).get("close") or {}).get("odds") or a.get("moneyLine")
    ph, pa = _ml_to_prob(hml), _ml_to_prob(aml)
    if ph is not None and pa is not None:
        s = ph + pa
        ph, pa = ph / s, pa / s
    return (spread if spread is not None else np.nan, total if total is not None else np.nan,
            ph if ph is not None else np.nan, pa if pa is not None else np.nan)


def parse_events(data, cfg):
    rows = []
    for ev in data.get("events", []) or []:
        try:
            comp = ev["competitions"][0]
            season = ev.get("season", {})
            if season.get("type") not in (2, 3, None):
                continue
            teams = {c["homeAway"]: c for c in comp["competitors"]}
            if "home" not in teams or "away" not in teams:
                continue
            key = "location" if cfg.get("college") else "displayName"
            home, away = teams["home"]["team"].get(key), teams["away"]["team"].get(key)
            if not home or not away:
                continue
            done = bool(ev.get("status", {}).get("type", {}).get("completed"))
            hs, as_ = _num(teams["home"].get("score")), _num(teams["away"].get("score"))
            spread, total, ph, pa = parse_odds(comp)
            rows.append(dict(game_id=int(ev["id"]), season=season.get("year"),
                             date=pd.to_datetime(ev["date"], utc=True).tz_localize(None),
                             home_team=home, away_team=away,
                             home_points=hs if done else np.nan, away_points=as_ if done else np.nan,
                             neutral_site=bool(comp.get("neutralSite")), completed=done,
                             spread_home=spread, total=total, home_ml_prob=ph))
        except (KeyError, IndexError, TypeError, ValueError):
            continue
    return rows


def fetch_day(cfg, day):
    params = {"dates": f"{day:%Y%m%d}", "limit": 1000}
    if cfg.get("groups"):
        params["groups"] = cfg["groups"]
    data = _get(cfg["path"], params)
    return parse_events(data, cfg) if data else None     # None = request failed (try again next run)


def day_fetch(cfg, days, deadline, workers=8):
    """Fetch many single days in parallel, newest first, stopping at the deadline. Returns (rows, days_done)."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    rows, done = [], set()
    days = sorted(days, reverse=True)
    with ThreadPoolExecutor(max_workers=workers) as ex:
        i = 0
        while i < len(days) and time.time() < deadline:
            batch = days[i:i + workers * 4]
            futs = {ex.submit(fetch_day, cfg, d): d for d in batch}
            for f in as_completed(futs):
                r = f.result()
                if r is not None:
                    rows += r
                    done.add(futs[f])
            i += len(batch)
    return rows, done


def season_days(cfg, start_year, today):
    """Calendar days that can have games for this sport (so the off-season is skipped)."""
    months = cfg["months"]
    out = []
    d = dt.date(start_year, 1, 1)
    while d <= today:
        if d.month in months:
            out.append(d)
        d += dt.timedelta(days=1)
    return out


def add_weeks(df):
    """ESPN only gives week numbers for football, so count weeks from each season's first game."""
    first = df.groupby("season")["date"].transform("min")
    df["week"] = ((df["date"] - first).dt.days // 7 + 1).astype(int)
    return df


def fetch_sport(key, root="data", days_ahead=7, today=None, budget_min=20):
    cfg = SPORTS[key]
    today = today or dt.date.today()
    os.makedirs(root, exist_ok=True)
    gpath = os.path.join(root, f"{key}_games.csv")
    dpath = os.path.join(root, f"{key}_days.txt")
    old = pd.read_csv(gpath, parse_dates=["date"]) if os.path.exists(gpath) else None
    seen = set(open(dpath).read().split()) if os.path.exists(dpath) else set()
    recent = {today - dt.timedelta(days=k) for k in range(0, 15)}
    todo = [d for d in season_days(cfg, cfg["start"], today) if d.isoformat() not in seen or d in recent]
    print(f"{key}: {len(todo)} days to read")
    rows, done = day_fetch(cfg, todo, time.time() + budget_min * 60)
    with open(dpath, "w") as f:
        f.write("\n".join(sorted(seen | {d.isoformat() for d in done if d not in recent})))
    new = pd.DataFrame(rows)
    fin = new[new["completed"]] if len(new) else new
    print(f"{key}: read {len(done)} of {len(todo)} days, {len(new)} games ({len(fin)} finished)")
    if len(fin):
        hist = pd.concat([old, fin.drop(columns=["completed"])]) if old is not None else fin.drop(columns=["completed"])
        hist = hist.drop_duplicates("game_id", keep="last").sort_values(["date", "game_id"]).reset_index(drop=True)
        hist["season"] = hist["season"].astype(int)
        hist = add_weeks(hist.drop(columns=["week"], errors="ignore"))
        cols = ["game_id", "season", "week", "date", "home_team", "away_team", "home_points", "away_points",
                "neutral_site", "spread_home", "total"]
        hist[cols].to_csv(gpath, index=False)
        print(f"{key}: {len(hist)} finished games saved -> {gpath}")
    elif old is None:
        raise SystemExit(f"{key}: no finished games parsed; the feed's shape may have changed.")
    ahead = [today + dt.timedelta(days=k) for k in range(0, days_ahead + 1)]
    up_rows, _ = day_fetch(cfg, ahead, time.time() + 300)
    up = pd.DataFrame(up_rows)
    cols_up = ["game_id", "season", "week", "date", "home_team", "away_team", "neutral_site", "spread_home", "total", "home_ml_prob"]
    if len(up):
        up = up[~up["completed"]].drop_duplicates("game_id").sort_values("date")
        up["week"] = 1
        up["season"] = up["season"].fillna(today.year).astype(int)
        up = up[cols_up]
    else:
        up = pd.DataFrame(columns=cols_up)
    upath = os.path.join(root, f"{key}_upcoming.csv")
    up.to_csv(upath, index=False)
    print(f"{key}: {len(up)} upcoming games, {int(up['spread_home'].notna().sum())} with a spread -> {upath}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("sport", choices=ORDER + ["all"])
    ap.add_argument("--root", default="data")
    ap.add_argument("--days", type=int, default=7)
    ap.add_argument("--budget", type=float, default=8.0, help="minutes to spend downloading per sport")
    a = ap.parse_args()
    for k in (ORDER if a.sport == "all" else [a.sport]):
        try:
            fetch_sport(k, a.root, a.days, budget_min=a.budget)
        except SystemExit as e:
            print(e)
