"""Margin models: gradient boosting on pre-game features.

Three modes, from least to most informed:
  blind     team strength only: Elo, recent form, opponent-adjusted offense/defense
            ratings, and preseason priors if available. No betting line at all.
            The honest test of "do I have my own signal?"
  aware     starts from the betting line and learns a correction using Elo and form.
            Anchored to the line, so it stays very close to it by construction.
  enhanced  starts from the line and gets everything else: offense/defense ratings,
            how the market has been pricing each team lately, totals form, how far
            the ratings disagree with the line, and preseason priors if available.

For aware and enhanced the model predicts the RESIDUAL (actual margin minus the
market margin) and adds it back to the line. Predicted margin becomes win and
cover probabilities with a normal distribution whose sigma comes from
out-of-sample (expanding-window) residuals.
"""
import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.ensemble import HistGradientBoostingRegressor

from .features import PRIOR_NAMES

BASE_FEATURES = ["elo_h", "elo_a", "elo_diff", "h_mar5", "a_mar5",
                 "h_pf5", "h_pa5", "a_pf5", "a_pa5",
                 "h_rest", "a_rest", "h_gp", "a_gp", "neutral", "week"]
RATING_FEATURES = ["h_off", "h_def", "a_off", "a_def", "rt_margin", "rt_total"]
MARKET_FORM = ["h_mres5", "a_mres5", "h_tres5", "a_tres5"]
ADV_FEATURES = ["h_oppa", "h_dppa", "a_oppa", "a_dppa", "h_osr", "h_dsr", "a_osr", "a_dsr", "ppa_edge", "sr_edge"]
MARKET_FEATURES = ["mkt_margin", "mkt_total", "gap_rt", "gap_elo"]
MODES = ("blind", "aware", "enhanced")
MARKET_MODES = ("aware", "enhanced")


def prior_features(df: pd.DataFrame) -> list:
    out = []
    for n in PRIOR_NAMES:
        for c in (f"h_{n}", f"a_{n}", f"{n}_diff"):
            if c in df.columns:
                out.append(c)
    return out


def adv_features(df: pd.DataFrame) -> list:
    return [c for c in ADV_FEATURES if c in df.columns]


def feature_cols(df: pd.DataFrame, mode: str) -> list:
    if mode == "blind":
        return BASE_FEATURES + RATING_FEATURES + prior_features(df) + adv_features(df)
    if mode == "aware":
        return BASE_FEATURES + ["mkt_margin"]
    if mode == "enhanced":
        return BASE_FEATURES + RATING_FEATURES + prior_features(df) + adv_features(df) + MARKET_FORM + MARKET_FEATURES
    raise ValueError(f"unknown mode {mode}")


def _hgb(**kw):
    # early_stopping is set explicitly: sklearn's 'auto' silently turns it on above
    # 10,000 training rows, which made model behavior change mid-backtest.
    p = dict(max_depth=3, learning_rate=0.04, max_iter=120, early_stopping=False,
             min_samples_leaf=80, l2_regularization=5.0, random_state=0)
    p.update(kw)
    return HistGradientBoostingRegressor(**p)


class MarginModel:
    def __init__(self, mode: str = "blind", **hgb_kw):
        if mode not in MODES:
            raise ValueError(f"mode must be one of {MODES}")
        self.mode = mode
        self.use_market = mode in MARKET_MODES
        self.hgb_kw = hgb_kw
        self.cols = None
        self.model = None
        self.sigma = 13.0

    def _X(self, df):
        return df[self.cols].astype(float)

    def _base(self, df):
        return df["mkt_margin"].astype(float).values if self.use_market else 0.0

    def _fit_one(self, df):
        tgt = df["margin"].values - (self._base(df) if self.use_market else 0.0)
        return _hgb(**self.hgb_kw).fit(self._X(df), tgt)

    def fit(self, df: pd.DataFrame):
        self.cols = feature_cols(df, self.mode)
        df = df.dropna(subset=["margin"])
        if self.use_market:
            df = df.dropna(subset=["mkt_margin"])
        seasons = sorted(df["season"].unique())
        resid = []
        for s in seasons[-3:]:  # expanding-window out-of-sample residuals
            tr, te = df[df["season"] < s], df[df["season"] == s]
            if tr["season"].nunique() < 2 or te.empty:
                continue
            m = self._fit_one(tr)
            pred = self._base(te) + m.predict(self._X(te))
            resid.append(te["margin"].values - pred)
        if resid:
            self.sigma = float(np.std(np.concatenate(resid)))
        self.model = self._fit_one(df)
        return self

    def predict_margin(self, df: pd.DataFrame) -> np.ndarray:
        return self._base(df) + self.model.predict(self._X(df))

    def win_prob(self, pred_margin):
        return norm.cdf(np.asarray(pred_margin) / self.sigma)

    def cover_prob(self, pred_margin, spread_home):
        """P(home covers). Home covers when margin + spread_home > 0."""
        return norm.cdf((np.asarray(pred_margin) + np.asarray(spread_home)) / self.sigma)
