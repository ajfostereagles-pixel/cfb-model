"""Sports betting model framework. College football first; sport-agnostic core."""
