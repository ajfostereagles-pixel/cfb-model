"""Builds one page per ESPN sport (docs/nfl.html, nba.html, ncaab.html, mlb.html, nhl.html) and the sport switcher.

    python dashboard/build_sports.py

Reads out/<sport>_predictions.csv, out/<sport>_graded.csv, out/<sport>_backtest.csv (made by run_sport.py).
"""
import datetime
import json
import os
import re
import sys

import numpy as np
import pandas as pd
from scipy.stats import norm

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
from sportsmodel.sports import ORDER, SPORTS  # noqa: E402

SHRINK = 0.25


def out(*p):
    return os.path.join(ROOT, "out", *p)


def available():
    return [k for k in ORDER if os.path.exists(out(f"{k}_backtest.csv"))]


def nav_html(current):
    items = [("cfb", "College football", "index.html")] + [(k, SPORTS[k]["name"], f"{k}.html") for k in available()]
    links = "".join(f'<a href="{h}"' + (' aria-current="page"' if k == current else "") + f">{n}</a>" for k, n, h in items)
    return f'<nav class="sportnav" aria-label="Sport">{links}</nav>'


def css_from_main():
    s = open(os.path.join(HERE, "template.html"), encoding="utf-8").read()
    return re.search(r"<style>(.*?)</style>", s, re.S).group(1)


def cards_block():
    s = open(os.path.join(HERE, "template.html"), encoding="utf-8").read()
    a = s.index("  function localTime(t)")
    b = s.index("  function renderWeek() {")
    return s[a:b].replace("won ' + (th.winPct * 100).toFixed(1) + '% in past seasons (' + fmtN(th.n) + ' picks)", "won ' + (th.winPct * 100).toFixed(1) + '% of tracked picks so far (' + fmtN(th.n) + ' graded)")


def accuracy(key):
    bt = pd.read_csv(out(f"{key}_backtest.csv"))
    if bt.empty:
        return None
    bt = bt[bt["margin"] != 0]
    rows = []
    for s, g in bt.groupby("season"):
        rows.append(dict(season=int(s), n=int(len(g)), su=float((np.sign(g.pred_margin) == np.sign(g.margin)).mean()),
                         home=float((g.margin > 0).mean()), mae=float(np.abs(g.margin - g.pred_margin).mean())))
    ov = dict(n=int(len(bt)), su=float((np.sign(bt.pred_margin) == np.sign(bt.margin)).mean()), home=float((bt.margin > 0).mean()),
              mae=float(np.abs(bt.margin - bt.pred_margin).mean()))
    p = norm.cdf(bt.pred_margin / bt.sigma)
    edges = [0, 0.3, 0.4, 0.5, 0.6, 0.7, 1.0001]
    cal = []
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (p >= lo) & (p < hi)
        if m.sum() >= 30:
            cal.append(dict(lo=int(round(lo * 100)), hi=min(100, int(round(hi * 100))), n=int(m.sum()), actual=float((bt.margin[m] > 0).mean())))
    return dict(seasons=rows, overall=ov, calib=cal)


def upcoming(key):
    path = out(f"{key}_predictions.csv")
    if not os.path.exists(path):
        return []
    p = pd.read_csv(path)
    res = []
    for r in p.itertuples(index=False):
        m = float(r.margin_used)
        tot = float(r.proj_total) if pd.notna(r.proj_total) else None
        res.append(dict(t=r.date, h=r.home_team, a=r.away_team, n=int(bool(r.neutral_site)),
                        sp=float(r.spread_home) if pd.notna(r.spread_home) else None,
                        tot=float(r.total) if pd.notna(r.total) else None,
                        ph=round((tot + m) / 2, 2) if tot is not None else None,
                        pa=round((tot - m) / 2, 2) if tot is not None else None,
                        m=round(m, 3), hw=round(float(r.home_win_prob), 4),
                        gap=round(float(r.gap), 3) if pd.notna(r.gap) else 0.0,
                        tier=r.tier, side=r.pick_side if isinstance(r.pick_side, str) else "",
                        ml=round(float(r.home_ml_prob), 4) if pd.notna(r.home_ml_prob) else None))
    return res


def graded(key):
    path = out(f"{key}_graded.csv")
    if not os.path.exists(path) or os.path.getsize(path) < 5:
        return []
    g = pd.read_csv(path)
    return [dict(h=r.home_team, a=r.away_team, hp=int(r.home_points), ap=int(r.away_points), sp=float(r.spread_home),
                 side=r.pick_side, tier=r.tier, result=r.result, u=float(r.units), date=str(r.date)[:10])
            for r in g.itertuples(index=False)]


def build(key):
    cfg = SPORTS[key]
    data = dict(sport=dict(key=key, name=cfg["name"], spread=bool(cfg["spread"]), label=cfg["label"]),
                upcoming=upcoming(key), graded=graded(key), acc=accuracy(key), shrink=SHRINK,
                asOf=datetime.datetime.now(datetime.timezone.utc).strftime("%b %d, %Y").replace(" 0", " "))
    tpl = open(os.path.join(HERE, "template_sport.html"), encoding="utf-8").read()
    tpl = tpl.replace("/*CSS*/", css_from_main()).replace("/*CARDS*/", cards_block())
    tpl = tpl.replace("<title>Gridiron Edge</title>", f"<title>Gridiron Edge {cfg['name']}</title>")
    tpl = tpl.replace("<!--SPORTNAV-->", nav_html(key))
    frag = tpl.replace("/*DATA*/null", json.dumps(data, separators=(",", ":"), allow_nan=False))
    title = re.search(r"<title>(.*?)</title>", frag).group(1)
    page = ("<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,viewport-fit=cover\">\n"
            f"<title>{title}</title>\n<style>body{{margin:0}}[hidden]{{display:none!important}}</style>\n"
            "</head>\n<body>\n" + frag.replace(f"<title>{title}</title>", "", 1) + "\n</body>\n</html>\n")
    os.makedirs(os.path.join(ROOT, "docs"), exist_ok=True)
    path = os.path.join(ROOT, "docs", f"{key}.html")
    open(path, "w", encoding="utf-8").write(page)
    print(f"wrote {path} ({len(data['upcoming'])} upcoming, {len(data['graded'])} graded)")


if __name__ == "__main__":
    for k in available():
        build(k)
