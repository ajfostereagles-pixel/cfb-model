"""Builds dashboard.html (three pages: This week, Results, Model details).

    python dashboard/build_dashboard.py

Reads  out/backtest_*.csv          (made by run.py backtest)
       out/predictions.csv         (made by run.py predict; this week's picks)  -- optional
       data/feed_preview.json      (fallback schedule with win chances only)    -- optional
Writes dashboard.html          (standalone: double-click it to open in your browser)
       dashboard/fragment.html (same page without the <html> wrapper, for publishing)
"""
import argparse
import json
import math
import os
import re

import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


def _pts(v):
    return int(v) if pd.notna(v) else None


def load_history():
    out = os.path.join(ROOT, "out")
    a = pd.read_csv(os.path.join(out, "backtest_aware.csv"))
    b = pd.read_csv(os.path.join(out, "backtest_blind.csv")).set_index("game_id")
    e = pd.read_csv(os.path.join(out, "backtest_enhanced.csv")).set_index("game_id")
    a = a.dropna(subset=["spread_home", "margin", "pred_margin"]).sort_values(["date", "game_id"]).reset_index(drop=True)
    teams = sorted(set(a["home_team"]) | set(a["away_team"]))
    return a, b, e, teams


def pred(df, gid):
    return round(float(df.at[gid, "pred_margin"]), 6) if gid in df.index and pd.notna(df.at[gid, "pred_margin"]) else None


def build_data(pred_path, feed_path, cur_season):
    a, b, e, teams = load_history()
    extra = set()
    up = []
    preview = False
    if pred_path and os.path.exists(pred_path):
        p = pd.read_csv(pred_path)
        for r in p.itertuples(index=False):
            m = float(r.margin_used)
            tot = float(r.proj_total) if pd.notna(r.proj_total) else None
            up.append(dict(t=r.date, h=r.home_team, a=r.away_team, n=int(bool(r.neutral_site)),
                           sp=float(r.spread_home) if pd.notna(r.spread_home) else None,
                           tot=float(r.total) if pd.notna(r.total) else None,
                           ph=round((tot + m) / 2, 2) if tot is not None else None,
                           pa=round((tot - m) / 2, 2) if tot is not None else None,
                           m=round(m, 3), hw=round(float(r.home_win_prob), 4),
                           gap=round(float(r.gap), 3) if pd.notna(r.gap) else None,
                           tier=r.tier, side=r.pick_side if isinstance(r.pick_side, str) else ""))
    elif feed_path and os.path.exists(feed_path):
        preview = True
        for f in json.load(open(feed_path, encoding="utf-8")):
            up.append(dict(t=f["t"], h=f["h"], a=f["a"], n=0, sp=None, tot=None, ph=None, pa=None, m=0,
                           hw=None, gap=None, tier="pending", side="", fp=round(f["fp"] * 100, 1) if f.get("fp") is not None else None))
    tix = {t: i for i, t in enumerate(teams)}
    rows = []
    for r in a.itertuples(index=False):
        rows.append([int(r.season), str(r.date)[:10], tix[r.home_team], tix[r.away_team],
                     float(r.spread_home), float(r.margin),
                     pred(b, r.game_id), round(float(r.pred_margin), 6), pred(e, r.game_id),
                     int(r.week), int(bool(r.neutral_site)), _pts(r.home_points), _pts(r.away_points)])
    return {"teams": teams, "games": rows, "upcoming": up, "preview": preview, "curSeason": cur_season}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--predictions", default=os.path.join(ROOT, "out", "predictions.csv"))
    ap.add_argument("--feed", default=os.path.join(ROOT, "data", "feed_preview.json"))
    ap.add_argument("--season", type=int, default=None)
    ap.add_argument("--out", default=os.path.join(ROOT, "dashboard.html"))
    ap.add_argument("--fragment", default=os.path.join(HERE, "fragment.html"))
    args = ap.parse_args()
    if args.season is None:
        import datetime
        t = datetime.date.today()
        args.season = t.year if t.month >= 7 else t.year - 1
    data = build_data(args.predictions, args.feed, args.season)
    tpl = open(os.path.join(HERE, "template.html"), encoding="utf-8").read()
    frag = tpl.replace("/*DATA*/null", json.dumps(data, separators=(",", ":"), allow_nan=False))
    open(args.fragment, "w", encoding="utf-8").write(frag)
    title = re.search(r"<title>(.*?)</title>", frag).group(1)
    page = ("<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1,viewport-fit=cover\">\n"
            f"<title>{title}</title>\n<style>:root{{color-scheme:light}}body{{margin:0}}[hidden]{{display:none!important}}</style>\n"
            "</head>\n<body>\n" + frag.replace(f"<title>{title}</title>", "", 1) + "\n</body>\n</html>\n")
    open(args.out, "w", encoding="utf-8").write(page)
    print(f"wrote {args.out}  ({len(data['games'])} past games, {len(data['upcoming'])} upcoming"
          f"{' (preview)' if data['preview'] else ''}, {os.path.getsize(args.out) / 1e6:.2f} MB)")


if __name__ == "__main__":
    main()
