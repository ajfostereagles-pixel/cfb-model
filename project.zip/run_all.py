"""One command: download the data, run the backtest, make this week's picks, build the dashboard
(college football first, then NFL, NBA, college basketball, MLB and NHL).

    python run_all.py

Run it again whenever you want fresh picks (for example every Tuesday or Wednesday).
"""
import os
import subprocess
import sys
import time

from sportsmodel.fetch_cfbd import current_season

py = sys.executable
season = str(current_season())
START = time.time()
TOTAL_MIN = 40   # keep the whole run well inside the 45 minute limit used on GitHub


def run(cmd, required=True):
    if subprocess.call(cmd) != 0:
        if required:
            sys.exit("\nStopped because a step failed. Copy the message above and send it to Claude.")
        print("\n(That optional step failed. Continuing without it.)\n")
        return False
    return True


os.makedirs("out", exist_ok=True)
run([py, "-m", "sportsmodel.fetch_cfbd", "--start", "2014", "--end", season, "--out", "data/cfb_games.csv"])
run([py, "-m", "sportsmodel.fetch_cfbd_extra", "--start", "2014", "--end", season], required=False)
run([py, "-m", "sportsmodel.fetch_cfbd_adv", "--start", "2014", "--end", season], required=False)
have_upcoming = run([py, "-m", "sportsmodel.fetch_cfbd_upcoming", "--out", "data/upcoming.csv"], required=False)
run([py, "run.py", "backtest", "--data", "data/cfb_games.csv"])
if have_upcoming and os.path.exists("data/upcoming.csv"):
    run([py, "run.py", "predict", "--data", "data/cfb_games.csv", "--upcoming", "data/upcoming.csv",
         "--out", "out/predictions.csv"], required=False)
from sportsmodel.sports import ORDER  # noqa: E402

for i, sport in enumerate(ORDER):   # the other sports: each one is optional, a failure in one never stops the rest
    left = max(1.0, (TOTAL_MIN * 60 - (time.time() - START)) / 60 - 3)
    budget = max(1.0, min(8.0, left / (len(ORDER) - i)))
    if run([py, "-m", "sportsmodel.fetch_espn", sport, "--budget", f"{budget:.1f}"], required=False):
        run([py, "run_sport.py", sport], required=False)
run([py, "dashboard/build_sports.py"], required=False)
run([py, "dashboard/build_dashboard.py"])
if os.path.isdir(".git") and os.path.isdir("docs"):   # on GitHub: stage the sport pages so the workflow commits them
    subprocess.call(["git", "add", "-f", "docs"])
print("\nDone. Open dashboard.html in your browser.")
print("To share it with Claude, attach data/cfb_games.csv and data/upcoming.csv (if it exists) and the printed results.")
