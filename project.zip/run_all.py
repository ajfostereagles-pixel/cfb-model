"""One command: download the data, run the backtest, make this week's picks, build the dashboard.

    python run_all.py

Run it again whenever you want fresh picks (for example every Tuesday or Wednesday).
"""
import os
import subprocess
import sys

from sportsmodel.fetch_cfbd import current_season

py = sys.executable
season = str(current_season())


def run(cmd, required=True):
    if subprocess.call(cmd) != 0:
        if required:
            sys.exit("\nStopped because a step failed. Copy the message above and send it to Claude.")
        print("\n(That optional step failed. Continuing without it.)\n")
        return False
    return True


os.makedirs("out", exist_ok=True)
run([py, "-m", "sportsmodel.fetch_cfbd", "--start", "2014", "--end", season, "--out", "data/cfb_games.csv"])
run([py, "-m", "sportsmodel.fetch_cfbd_extra", "--start", "2014", "--end", season], required=False)
run([py, "-m", "sportsmodel.fetch_cfbd_adv", "--start", "2014", "--end", season], required=False)
have_upcoming = run([py, "-m", "sportsmodel.fetch_cfbd_upcoming", "--out", "data/upcoming.csv"], required=False)
run([py, "run.py", "backtest", "--data", "data/cfb_games.csv"])
if have_upcoming and os.path.exists("data/upcoming.csv"):
    run([py, "run.py", "predict", "--data", "data/cfb_games.csv", "--upcoming", "data/upcoming.csv",
         "--out", "out/predictions.csv"], required=False)
run([py, "dashboard/build_dashboard.py"])
print("\nDone. Open dashboard.html in your browser.")
print("To share it with Claude, attach data/cfb_games.csv and data/upcoming.csv (if it exists) and the printed results.")
